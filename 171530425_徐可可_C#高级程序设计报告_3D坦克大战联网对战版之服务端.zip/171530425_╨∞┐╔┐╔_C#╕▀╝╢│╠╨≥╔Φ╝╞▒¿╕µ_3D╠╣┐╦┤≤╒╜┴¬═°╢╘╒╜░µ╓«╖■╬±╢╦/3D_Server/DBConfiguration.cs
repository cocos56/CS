﻿// 将此文件更名为DBConfiguration.cs，并对以下变量进行赋值

namespace Game
{
	class DBConfiguration
	{
		public static string db= "game";
		public static string ip = "coco56.top";
		public static int port = 6603;
		public static string user = "zj175";
		public static string pw = "i,@mc0c0@my";
	}
}