﻿public class PlayerData{
	//金币
	public int coin = 0;
	//记事本
	public string text = "new text";
	//胜利数
	public int win = 0;
	//失败数
	public int lost = 0;
}