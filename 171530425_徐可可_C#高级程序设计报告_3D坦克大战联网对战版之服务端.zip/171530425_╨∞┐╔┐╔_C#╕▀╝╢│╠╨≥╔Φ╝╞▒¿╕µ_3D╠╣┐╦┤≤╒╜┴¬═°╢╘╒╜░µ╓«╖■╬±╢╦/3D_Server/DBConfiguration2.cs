﻿// 将此文件更名为DBConfiguration.cs，并对以下变量进行赋值

namespace Game
{
	class DBConfiguration
	{
		public static string db= "game";
		public static string ip = "127.0.0.1";
		public static int port = 3306;
		public static string user = "root";
		public static string pw = "aa123bb456";
	}
}